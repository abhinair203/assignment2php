<?php
// Database connection
$servername = "localhost";
$username = "justins";
$password = "daivame29";
$dbname = "user_crud";

$conn = new mysqli($servername, $username, $password, $dbname, 3307);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
