
<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Success</title>
    <!-- <link rel="stylesheet" type="text/css" href="css/styles.css"> -->
</head>
<body>
    <div class="container">
        <h1>Welcome to the Restricted Page!</h1>
        <p>This page is only visible after login.</p>
        <a href="./logout.php">Logout</a>
    </div>
</body>
</html>
