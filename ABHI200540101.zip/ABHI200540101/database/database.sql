-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 11, 2023 at 05:19 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('Justin Varghese', '$2y$10$mdwi1ZuwB9PV9mS38uY3hOYCWVC/riLzmwt/lp/bUnRW3HKIXZSOW'),
('justin@gmail.com', '$2y$10$ggXaFYqp5W/STpm6pyqPJuXzIDRw75G2zbt9DTZbgB/jtCbwqSQU.'),
('admin', '$2y$10$YWUayeNKSxcGyUCX.Pbhkuxi6S767/qoHYN9j7ZnAHw2wtvdxbRTC'),
('a@gmail.com', '$2y$10$vbEMgcoq22gPAUlLEvDX7uNKyqIyLZd9sSC0Ly55V73zb3sr3ZVdO'),
('justinnn07', '$2y$10$C0E2CwV8L2TfEIjFPsmMt.Yf6KVVncEJm10aSgL1vaFD7FUPi7Aw6');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
